import random

def hangman():
    # Predefined list of words
    words = ["python", "java", "hangman", "programming", "computer"]
    
    # Randomly choose a word
    word = random.choice(words)
    guessed_word = ["_"] * len(word)  # underscores for unguessed letters
    guessed_letters = []  # track guessed letters
    attempts_left = 6  # wrong guesses allowed
    
    print("🎮 Welcome to Hangman Game!")
    print("Guess the word, one letter at a time.")
    print("You have 6 incorrect guesses allowed.\n")

    # Main game loop
    while attempts_left > 0 and "_" in guessed_word:
        print("Word: ", " ".join(guessed_word))
        print("Guessed letters: ", " ".join(guessed_letters))
        print(f"Attempts left: {attempts_left}")
        
        guess = input("Enter a letter: ").lower()
        
        if not guess.isalpha() or len(guess) != 1:
            print("❌ Invalid input. Enter a single letter.\n")
            continue
        
        if guess in guessed_letters:
            print("⚠️ You already guessed that letter.\n")
            continue
        
        guessed_letters.append(guess)
        
        if guess in word:
            print(f"✅ Good guess! '{guess}' is in the word.\n")
            for i in range(len(word)):
                if word[i] == guess:
                    guessed_word[i] = guess
        else:
            print(f"❌ Wrong guess! '{guess}' is not in the word.\n")
            attempts_left -= 1
    
    # End of game
    if "_" not in guessed_word:
        print("🎉 Congratulations! You guessed the word:", word)
    else:
        print("💀 Game Over! The word was:", word)

# Run the game
if __name__ == "__main__":
    hangman()
