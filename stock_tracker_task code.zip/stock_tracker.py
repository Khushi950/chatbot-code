import csv

def stock_portfolio():
    # Hardcoded stock prices
    stock_prices = {
        "AAPL": 180,
        "TSLA": 250,
        "GOOGL": 135,
        "MSFT": 300,
        "AMZN": 140
    }
    
    portfolio = {}
    total_value = 0
    
    print("📈 Welcome to Stock Portfolio Tracker!")
    print("Available stocks:", ", ".join(stock_prices.keys()))
    print("Type 'done' when finished adding stocks.\n")
    
    while True:
        stock = input("Enter stock symbol: ").upper()
        if stock == "DONE":
            break
        if stock not in stock_prices:
            print("❌ Stock not available. Try again.")
            continue
        
        try:
            qty = int(input(f"Enter quantity for {stock}: "))
        except ValueError:
            print("❌ Invalid quantity. Enter a number.")
            continue
        
        portfolio[stock] = portfolio.get(stock, 0) + qty
    
    print("\nYour Portfolio:")
    for stock, qty in portfolio.items():
        value = stock_prices[stock] * qty
        total_value += value
        print(f"{stock}: {qty} shares = ${value}")
    
    print(f"\n💰 Total Investment Value: ${total_value}")
    
    # Ask to save as CSV
    save = input("Do you want to save the result to portfolio.csv? (yes/no): ").lower()
    if save == "yes":
        with open("portfolio.csv", "w", newline="") as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(["Stock", "Quantity", "Price", "Value"])
            for stock, qty in portfolio.items():
                writer.writerow([stock, qty, stock_prices[stock], stock_prices[stock]*qty])
            writer.writerow(["Total", "", "", total_value])
        print("✅ Portfolio saved to portfolio.csv")

if __name__ == "__main__":
    stock_portfolio()
